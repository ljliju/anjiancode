%% 
clear,clc
sheet=dir('*.xlsx');

for i=1:2;
    data=importdata(sheet(i).name,'Go_nogo');
    [sep_data raw_data]=go_nogo_seperate(data);%分为不同试次，不同的侧手以及原始数据
    index_all=go_nogo_index(sep_data.go,sep_data.nogo);
    gonogo_all(i,:)=index_all;
end

gonogo_result=cell2table(gonogo_all,'VariableNames',{'mean_go_rt' 'go_acc' 'mean_nogo_rt' 'nogo_acc'})
save('gonogo.mat','gonogo_result')
% mean_all=nanmean(all);%the mean of all hands

for i=1:2;
    data=importdata(sheet(i).name,'Stop');
    [sep_data raw_data]=stop_go_seperate(data);%分为不同试次，不同的侧手以及原始数据
    [all_index]=SSRT_mean(sep_data)
    Stop_all(i,:)=table2cell(all_index);
end
Stop_result=[all_index.Properties.VariableNames;Stop_all];
save('Stop_result.mat','Stop_result')

for i=1:length(sheet);    
    data=importdata(sheet(i).name,'Change');
    [sep_data,raw_data]=change_go_seperate(data);
    Change_result(i,:)=change_result(raw_data,sep_data);
    
end
save('Change_result.mat','Change_result')
