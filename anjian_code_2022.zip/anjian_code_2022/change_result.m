function [FR]=change_result(raw_data,sep_data)
% 得到change任务的准确率，不分左右手，左手，右手

% % % % % % % % % % % 总试次的正确率————————
% ACC_1 = cell2mat(raw_data(2:end,1)); 
ACC_1 = raw_data{:,1};
Right_index_1 = find(ACC_1==1);Wrong_index_1 = find(ACC_1==0); 
ACC_Both = length(Right_index_1)/length(ACC_1);% 总试次的正确率

% % % % % % % % % % % 右手试次的正确率————————
right_trial=sep_data.right;
ACC_2=right_trial{:,1};
Right_index_2 = find(ACC_2==1); Wrong_index_2 = find(ACC_2==0); 
ACC_Right = length(Right_index_2)/length(ACC_2);% 右手的正确率

% % % % % % % % % % % 左手试次的正确率————————
left_trial=sep_data.left;
ACC_3=left_trial{:,1};
Right_index_3 = find(ACC_3==1);Wrong_index_3 = find(ACC_3==0); 
ACC_left = length(Right_index_3)/length(ACC_3);% 左手的正确率

% % % % % % % % % % % 总试次的RT && CSRT————————
% RT_1=cell2mat(raw_data(2:end,2)); SSD=cell2mat(raw_data(2:end,3));

RT_1=raw_data{:,2}; SSD=raw_data{:,3};
Mean_RT_1=nanmean(RT_1(Right_index_1));Mean_SSD_1=nanmean(SSD(Right_index_1));
CSRT_1=Mean_RT_1-Mean_SSD_1;

% % % % % % % % % % % 右手试次的RT && CSRT————————

RT_2=right_trial{1:end,2}; SSD_2=right_trial{1:end,3};
Mean_RT_2=nanmean(RT_2(Right_index_2));Mean_SSD_2=nanmean(SSD_2(Right_index_2));
CSRT_2=Mean_RT_2-Mean_SSD_2;

% % % % % % % % % % % 左手试次的RT && CSRT————————
RT_3=left_trial{1:end,2}; SSD_3=left_trial{1:end,3};
Mean_RT_3=nanmean(RT_3(Right_index_3));Mean_SSD_3=nanmean(SSD_3(Right_index_3));
CSRT_3=Mean_RT_3-Mean_SSD_3;

% % % % % % % % % % % 不正确试次的RT && CSRT————————
Mean_Wrong_1=nanmean(RT_1(Wrong_index_1));
Mean_Wrong_2=nanmean(RT_2(Wrong_index_2));
Mean_Wrong_3=nanmean(RT_3(Wrong_index_3));

% % % % % % 结果汇总————————

result=struct('All_ACC',ACC_Both,'R_ACC',ACC_Right,'L_ACC',ACC_left,...
          'All_RT',Mean_RT_1,'R_RT',Mean_RT_2,'L_RT',Mean_RT_3,...
         'All_CSRT',CSRT_1,'R_CSRT',CSRT_2,'L_CSRT',CSRT_3,...
        'Wrong_All_RT',Mean_Wrong_1,'Wrong_R_RT',Mean_Wrong_2,'Wrong_L_RT',Mean_Wrong_3);
FR=struct2table(result);
end