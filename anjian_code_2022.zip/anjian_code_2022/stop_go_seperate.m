%%
function [data raw_data]=stop_go_seperate(sheetname);

%[stop_trial go_trial raw_data left_trial right_trial]=stop_go_seperate(sheetname);
% [a b c]=xlsread( sheetname);raw_data=c;
c=sheetname;
ind_stop=zeros(size(c,1),1);ind_go=zeros(size(c,1),1);
ind_left=zeros(size(c,1),1);ind_right=zeros(size(c,1),1);
variables={'ACC','RT','SSD','Name','Arrow','interval'};

for i=1:size(c,1);
    
    if strcmp('strop',c{i,4})==1 || strcmp( 'strop	',c{i,4})==1 || strcmp('stop',c{i,4})==1;%% 4/5
        ind_stop(i)=i;
    elseif strcmp('go',c{i,4})==1 || strcmp('go	',c{i,4})==1;
        ind_go(i)=i;
    end
    ind_stop(find(ind_stop==0))=[];ind_go(find(ind_go==0))=[];
    stop_trial=c([ind_stop],:);go_trial=c([ind_go],:);
    
end


for i=1:size(c,1)
    
    if strcmp('left',c{i,5})==1 || strcmp('left	',c{i,5})==1;
        ind_left(i)=i;
    elseif strcmp('right',c{i,5})==1 || strcmp('right	',c{i,5})==1
        ind_right(i)=i;
    end   
    ind_left(find(ind_left==0))=[];ind_right(find(ind_right==0))=[];   
    left_trial=c([ind_left],:);right_trial=c([ind_right],:);

f1='stop';f2='go';f3='left';f4='right';
data=struct(f1,stop_trial,f2,go_trial,f3,left_trial,f4,right_trial);
data=data(1);
raw_data=c;

  echo off
end
