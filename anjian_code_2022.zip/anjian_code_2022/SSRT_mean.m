function result=SSRT_mean(sep_data);

go=sep_data.go; rt=go{:,2};
wrong_index=find(rt(:,1)==0);
rt(wrong_index)=[];mean_rt=nanmean(rt);ACC_GO=1-length(wrong_index)/size(go,1);

stop=sep_data.stop;ssd=stop{:,3};
wrong_index=find(stop{:,1}==0);
ssd(wrong_index)=[];mean_ssd=nanmean(ssd);ACC_Stop=1-length(wrong_index)/size(stop,1);
unseccessful_stop=stop(wrong_index,:);unseccessful_rt=mean(unseccessful_stop{:,2});
SSRT=mean_rt-mean_ssd;



result=struct('ACC_go',ACC_GO,'GO_RT',mean_rt,'ACC_Stop',...
    ACC_Stop,'unsuccessful_stop_rt',unseccessful_rt,'SSRT',SSRT);
result=struct2table(result);


end