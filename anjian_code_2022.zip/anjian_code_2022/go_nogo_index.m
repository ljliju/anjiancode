function index=go_nogo_index(go,nogo);
%%% 计算go的准确率和反应时，Nogo的正确率和错误nogo的反应时

% % % % % data is the different hand
% data=side.left;
% nogo=data.nogo;go=data.go;
% go.Properties.VariableNames
% go=sep_data.go;nogo=sep_data.nogo;


go_rt=go(:,2).Variables;
go_rt(find(go_rt==0),:)=[];
mean_go_rt=mean(go_rt);go_acc=length(go_rt)/size(go,1);%go的平均反应时和准确率。
% % % % % nogo
nogo_rt=nogo{:,2};nogo_rt(find(nogo_rt==0))=[];
mean_nogo_rt=mean(nogo_rt);%wrong_trials_nogo的反应时间
nogo_acc=1-length(nogo_rt)/size(nogo,1);%nogo的准确率。

index={mean_go_rt,go_acc,mean_nogo_rt,nogo_acc}
echo off
end

% %% test
% go=side.left.go;nogo=side.left.nogo;